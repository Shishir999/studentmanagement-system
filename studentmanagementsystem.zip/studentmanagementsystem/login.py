import MySQLdb
from Tkinter import *
from register import *
from tkFont import Font
from tkMessageBox import *

try:
    from ttk import Entry, Button
except ImportError:
    pass

class Login(object):
    def __init__(self):
        self.root = Tk()
        self.root.title(u'Sign in')
        self.root.resizable(False, False)
        self.root.geometry('+450+250')
        self.sysfont = Font(self.root, size=15)
        self.lb_user = Label(self.root, text=u'User name:',width = 20,height = 10,font=("Blackbody", 15, "bold"))
        self.lb_passwd1 = Label(self.root, text=u'')
        self.lb_passwd = Label(self.root, text=u'Password:',width = 20,height = 5,font=("Blackbody", 15, "bold"))
        self.lb_user.grid(row=0, column=0, sticky=W)
        self.lb_passwd1.grid(row=1, column=0, sticky=W)
        self.lb_passwd.grid(row=2, column=0, sticky=W)

        self.en_user = Entry(self.root, font=self.sysfont, width=24)
        self.en_passwd = Entry(self.root, font=self.sysfont, width=24)
        self.en_user.grid(row=0, column=1, columnspan=1)
        self.en_passwd.grid(row=2, column=1, columnspan=1)
        self.en_user.insert(0, u'enter one user name')
        self.en_passwd.insert(0, u'Please input a password')
        self.en_user.config(validate='focusin',
                            validatecommand=lambda: self.validate_func('self.en_user'),
                            invalidcommand=lambda: self.invalid_func('self.en_user'))
        self.en_passwd.config(validate='focusin',
                              validatecommand=lambda: self.validate_func('self.en_passwd'),
                              invalidcommand=lambda: self.invalid_func('self.en_passwd'))

        self.var = IntVar()
        self.ckb = Checkbutton(self.root, text=u'Remember user name and password', underline=0,
                               variable=self.var,font=(15))
        self.ckb.grid(row=3, column=0)
        self.bt_print = Button(self.root, text=u'Land')
        self.bt_print.grid(row=3, column=1, sticky=E, pady=50,padx = 10)
        self.bt_print.config(command=self.print_info)

        self.bt_register = Button(self.root, text=u'register')
        self.bt_register.grid(row=3, column=2, sticky=E, pady=50, padx=50)
        self.bt_register.config(command=self.register_info)
        # self.root.bind('<Return>', self.enter_print)
        self.root.mainloop()

    def validate_func(self, en):
        return False if eval(en).get().strip() != '' else True

    def invalid_func(self, en):
        value = eval(en).get().strip()
        if value == u'enter one user name' or value == u'Input password':
            eval(en).delete(0, END)
        if en == 'self.en_passwd':
            eval(en).config(show='*')

    def print_info(self):
        en1_value = self.en_user.get().strip()
        en2_value = self.en_passwd.get().strip()
        txt = u'''User name: %s \n Password  : %s ''' % (self.en_user.get(), self.en_passwd.get())
        if en1_value == '' or en1_value == u'enter one user name':
            showwarning(u'Username', u'enter one user name')
        elif en2_value == '' or en2_value == u'Input password':
            showwarning(u'No password', u'Please input a password')
        else:
            a = 0
            # Open database connection
            db = MySQLdb.connect("localhost", "root", "root", "book")
            # Use cursor()Method to get operation cursor
            cursor = db.cursor()
            # SQL Query statement
            sql = "select * from user"
            try:
                # implement SQL Sentence
                cursor.execute(sql)
                # Get a list of all records
                results = cursor.fetchall()
                for row in results:
                    id = row[0]
                    name = row[1]
                    pwd = row[2]
                    if name == en1_value and pwd == en2_value:
                        a = 1
                        print "Successful database connection and validation!!!"
                        showinfo('Landing success!!!', txt)
                    # # Print results
                    # print "id=%d,name=%s,pwd=%s" % \
                    #       (id, name, pwd)
            except:
                print "Error: unable to fecth data"

            # Close database connection
            db.close()
            if(a == 0):
                showinfo('Error in username or password!!!', txt)

    def register_info(self):
        self.rootR = Tk()
        loginPage(self.rootR)
        self.root.withdraw()

    def enter_print(self, event):
        self.print_info()

if __name__ == "__main__":
    Login()