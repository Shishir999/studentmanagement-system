import MySQLdb
from login import *
from Tkinter import *
import string

class loginPage(object):
    def __init__(self, master, info='Welcome to the registration page'):
        self.master = master
        self.mainlabel = Label(master, text=info, justify=CENTER)
        self.mainlabel.grid(row=0, columnspan=3)

        self.user = Label(master, text='Registered User Name:', borderwidth=3)
        self.user.grid(row=1, sticky=W)

        self.pwd = Label(master, text='Registration password:', borderwidth=3)
        self.pwd.grid(row=2, sticky=W)

        self.userEntry = Entry(master)
        self.userEntry.grid(row=1, column=1, columnspan=3)
        self.userEntry.focus_set()

        self.pwdEntry = Entry(master, show='*')
        self.pwdEntry.grid(row=2, column=1, columnspan=3)

        self.loginButton = Button(master, text='Confirm registration', borderwidth=2, command=self.login)
        self.loginButton.grid(row=3, column=1)

        self.clearButton = Button(master, text='Return', borderwidth=2, command=self.clear)
        self.clearButton.grid(row=3, column=2)

    def login(self):
        self.username = self.userEntry.get().strip()
        self.passwd = self.pwdEntry.get().strip()
        # Open database connection
        db = MySQLdb.connect("localhost", "root", "root", "book")
        # Use cursor()Method to get operation cursor
        cursor = db.cursor()
        # SQL Insert statement
        sql = "INSERT INTO user(name, pwd) VALUES ('%s', '%s')" % (self.username, self.passwd)
        try:
            # implement sql Sentence
            cursor.execute(sql)
            print "Data insertion success!!!"
            # Submit to database for execution
            db.commit()
        except:
            print "Data insertion failed!!!"
            # Rollback in case there is any error
            db.rollback()

        # Close database connection
        db.close()



    def clear(self):
        self.userEntry.delete(0, END)
        self.pwdEntry.delete(0, END)
        Login()

if __name__ == '__main__':
    root = Tk()
    root.title('register')
    myLogin = loginPage(root)

    # root.wait_window(myLogin.mySendMail.sendPage)
    mainloop()